# 🚀 Rio Laser Dashboard — Guia de Instalação

## O que você vai precisar
- Conta no Replit (replit.com) — gratuita
- Client ID e Client Secret do QuickBooks Developer

---

## PASSO 1 — Configurar o app no QuickBooks Developer

1. Acesse: https://developer.intuit.com
2. Faça login com sua conta Intuit (a mesma do QuickBooks)
3. Clique em **"Create an app"**
4. Escolha **QuickBooks Online and Payments**
5. Dê o nome: `Rio Laser Dashboard`
6. Em **Keys & OAuth**, copie o **Client ID** e **Client Secret** da aba **Production**
7. Em **Redirect URIs**, você vai adicionar a URL do Replit depois (volte aqui no passo 3)

---

## PASSO 2 — Criar o projeto no Replit

1. Acesse: https://replit.com
2. Clique em **"+ Create Repl"**
3. Escolha o template **Node.js**
4. Nome do projeto: `rio-laser-dashboard`
5. Clique em **Create Repl**

---

## PASSO 3 — Fazer upload dos arquivos

No Replit, no painel esquerdo (Files):

1. Crie a pasta `frontend/public/`
2. Faça upload dos arquivos:
   - `backend/server.js` → raiz do projeto (`server.js`)
   - `backend/package.json` → raiz do projeto (`package.json`)
   - `frontend/public/index.html` → `frontend/public/index.html`

---

## PASSO 4 — Configurar as variáveis de ambiente

No Replit, clique no ícone de **cadeado (Secrets)** no painel esquerdo:

Adicione cada uma dessas variáveis:

| Chave | Valor |
|-------|-------|
| `QB_CLIENT_ID` | (seu Client ID do passo 1) |
| `QB_CLIENT_SECRET` | (seu Client Secret do passo 1) |
| `REDIRECT_URI` | (veja abaixo) |
| `SESSION_SECRET` | riolaser-segredo-2024 |

**Para o REDIRECT_URI:**
- No Replit, clique em **Run** uma vez
- Copie a URL que aparece (ex: `https://rio-laser-dashboard.seuusuario.repl.co`)
- O Redirect URI será: `https://rio-laser-dashboard.seuusuario.repl.co/callback`

---

## PASSO 5 — Registrar o Redirect URI no QuickBooks

1. Volte ao Intuit Developer Portal
2. Em **Redirect URIs**, clique em **Add URI**
3. Cole a URL do passo 4: `https://rio-laser-dashboard.seuusuario.repl.co/callback`
4. Salve

---

## PASSO 6 — Rodar o app

No Replit, clique em **Run**.

O dashboard vai abrir automaticamente. Você verá a tela inicial.

---

## PASSO 7 — Conectar as empresas

1. No dashboard, clique em **"Conectar empresa"**
2. Faça login com o QuickBooks da primeira Rio Laser
3. Autorize o acesso
4. Você voltará ao dashboard com a empresa aparecendo
5. **Repita para cada uma das 7 empresas** — cada clique em "Conectar empresa" permite adicionar uma nova sem remover as anteriores!

---

## ✅ Pronto!

O dashboard vai mostrar automaticamente:
- Revenue MTD
- Expenses MTD
- Net Income MTD
- Bank Balance (se a conta bancária estiver conectada no QuickBooks)
- Totais consolidados do grupo

Os dados se atualizam automaticamente a cada 5 minutos.

---

## Dúvidas frequentes

**"Preciso fazer login toda vez que abrir?"**
Não. Os tokens ficam salvos enquanto o Replit estiver rodando. Se reiniciar, basta reconectar as empresas uma vez.

**"Como deixar rodando 24/7?"**
No plano gratuito do Replit, o app hiberna após inatividade. Para manter sempre ativo, assine o Replit Core (~$7/mês) ou use um serviço como UptimeRobot para fazer ping a cada 5 minutos.

**"Como adicionar mais métricas no futuro?"**
É só pedir para o Claude expandir o `server.js` e o `index.html` com as novas informações.
